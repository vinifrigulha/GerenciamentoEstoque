﻿using GerenciamentoDeEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores
{
    public class Comprador : Funcionario
    {
        Dictionary<string, Cotacao> listaCotacao = new Dictionary<string, Cotacao>();
        List<Produto> listaProdutos = new List<Produto>();
        public Comprador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone)
            : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'C';
            id = tipoFuncionario + "-" + id;
            CriarListaProdutos();
        }

        // Menu
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO COMPRADOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Criar Cotação");
                Console.WriteLine("\t[2] Exibir Cotações");
                Console.WriteLine("\t[3] Alterar Status da Cotação");
                Console.WriteLine("\t[4] Alterar Data Limite");
                Console.WriteLine("\t[5] Adicionar Item à Cotação");
                Console.WriteLine("\t[6] Remover Item da Cotação");
                Console.WriteLine("\t[7] Visualizar Perfil");
                Console.WriteLine("\t[8] Alterar Senha");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaC;
                try
                {
                    respostaC = int.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaC = -1;
                }

                Console.Clear();
                switch (respostaC)
                {
                    case 1:
                        CriarCotacao();
                        break;

                    case 2:
                        Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE COTAÇÕES -=-=-=-=-=-=-=-=-\n");
                        ExibirCotacoes();
                        Console.Write("Aperte 'Enter' para continuar...");
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case 3:
                        AlterarStatusCotacao();
                        break;

                    case 4:
                        AlterarDataVencimento();
                        break;

                    case 5:
                        Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE COTAÇÕES -=-=-=-=-=-=-=-=-\n");
                        ExibirCotacoes();
                        AdicionarItem();
                        break;

                    case 6:
                        Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE COTAÇÕES -=-=-=-=-=-=-=-=-\n");
                        ExibirCotacoes();
                        RemoverItens();
                        break;

                    case 7:
                        VisualizarDados();
                        break;

                    case 8:
                        AlterarSenha();
                        break;

                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }

        private void CriarListaProdutos()
        {
            // Adicione produtos à listaProdutos conforme necessário
            Produto produto1 = new Produto("Maçã", 2.5m, "2023-12-31", 100, "Unidade", "Setor de Frutas");
            Produto produto2 = new Produto("Camiseta", 29.99m, "2023-12-31", 50, "Peça", "Setor de Vestuário");
            Produto produto3 = new Produto("Caderno", 8.99m, "2024-12-31", 80, "Unidade", "Setor de Papelaria");
            Produto produto4 = new Produto("Sapato", 49.99m, "2023-12-31", 20, "Par", "Setor de Calçados");
            Produto produto5 = new Produto("Leite", 3.0m, "2023-12-15", 30, "Litro", "Setor de Laticínios");
            Produto produto6 = new Produto("Caneta", 1.5m, "2024-12-31", 100, "Unidade", "Setor de Papelaria");
            Produto produto7 = new Produto("Arroz", 12.0m, "2024-12-31", 40, "Quilo", "Setor de Grãos");
            Produto produto8 = new Produto("Tênis", 79.99m, "2023-12-31", 15, "Par", "Setor de Calçados");
            Produto produto9 = new Produto("Mochila", 39.99m, "2024-12-31", 25, "Unidade", "Setor de Bolsas");
            Produto produto10 = new Produto("Pasta de Dente", 4.5m, "2023-12-31", 60, "Unidade", "Setor de Higiene");

            // Adicione os produtos à lista
            listaProdutos.Add(produto1);
            listaProdutos.Add(produto2);
            listaProdutos.Add(produto3);
            listaProdutos.Add(produto4);
            listaProdutos.Add(produto5);
            listaProdutos.Add(produto6);
            listaProdutos.Add(produto7);
            listaProdutos.Add(produto8);
            listaProdutos.Add(produto9);
            listaProdutos.Add(produto10);
        }


        private void ExibirListaProdutos()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE PRODUTOS -=-=-=-=-=-=-=-=-\n");

            foreach (Produto produto in listaProdutos)
            {
                Console.WriteLine($"ID Produto: {produto.GetIdProduto()} \nDescrição: {produto.GetDescricao()} \nValor: {produto.GetValor()} \nEstoque: {produto.GetEstoque()}\n");
            }
        }

        private void AdicionarItem()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ADICIONAR ITEM À COTAÇÃO -=-=-=-=-=-=-=-=-\n");
            ExibirCotacoes();

            Console.Write("Digite o ID da cotação à qual deseja adicionar o item (ou 'C' para cancelar): ");
            string idCotacao = Console.ReadLine();

            if (idCotacao.ToUpper() == "C")
            {
                Console.Clear();
                Console.WriteLine("Operação cancelada pelo usuário.\n");
                return;
            }

            if (listaCotacao.ContainsKey(idCotacao))
            {
                Console.Clear();
                Console.WriteLine("-=-=-=-=-=-=-=- ADICIONAR ITEM À COTAÇÃO -=-=-=-=-=-=-=-=-\n");
                ExibirListaProdutos(); // Exibindo a lista de produtos

                Console.Write("Digite o ID do produto a ser adicionado à cotação: ");
                string idProduto = Console.ReadLine();

                Produto produtoSelecionado = listaProdutos.FirstOrDefault(p => p.GetIdProduto() == idProduto);

                if (produtoSelecionado != null)
                {
                    listaCotacao[idCotacao].AdicionarItem(produtoSelecionado);
                    Console.Clear();
                    Console.WriteLine("Item adicionado com sucesso à cotação!\n");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("ID do produto não encontrado.\n");
                }
            }
            else
            {
                Console.WriteLine("ID da cotação não encontrado.\n");
            }
        }
        private void RemoverItens()
        {
            Console.Write("Digite o ID da cotação (ou 'C' para cancelar): ");
            string idCotacao = Console.ReadLine();

            if (idCotacao.ToUpper() == "C")
            {
                Console.Clear();
                Console.WriteLine("Operação cancelada pelo usuário.\n");
                return;
            }

            while (true)
            {
                if (listaCotacao.ContainsKey(idCotacao))
                {
                    Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE ITENS DA COTAÇÃO -=-=-=-=-=-=-=-=-\n");

                    // Exibir lista de itens da cotação
                    listaCotacao[idCotacao].ExibirItens();

                    if (listaCotacao[idCotacao].GetListaProdutos().Count > 0)
                    {
                        Console.Write("Digite o ID do produto a ser removido da cotação (ou 'C' para cancelar): ");
                        string idProduto = Console.ReadLine();

                        if (idProduto.ToUpper() == "C")
                        {
                            Console.Clear();
                            Console.WriteLine("Operação cancelada pelo usuário.\n");
                            return;
                        }

                        if (listaCotacao[idCotacao].RemoverItem(idProduto))
                        {
                            Console.Clear();
                            Console.WriteLine("Item removido com sucesso!\n");
                            break;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("ID do produto não encontrado na cotação.\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Esta cotação não tem itens.\n");
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("ID da cotação não encontrado. Tente novamente (ou 'C' para cancelar).\n");
                    idCotacao = Console.ReadLine();

                    if (idCotacao.ToUpper() == "C")
                    {
                        Console.Clear();
                        Console.WriteLine("Operação cancelada pelo usuário.\n");
                        return;
                    }
                }
            }
        }

        // Métodos do Comprador
        public void CriarCotacao()
        {
            Cotacao cotacao = new Cotacao(id);
            listaCotacao.Add(cotacao.GetIdCotacao(), cotacao);
            Console.Clear();
            Console.WriteLine("Cotação criada com sucesso!\n");
        }
        public void ExibirCotacoes()
        {
            foreach (KeyValuePair<string, Cotacao> cotacao in listaCotacao)
            {
                Console.WriteLine($"ID Cotação: {cotacao.Key} \nData de Criação: {cotacao.Value.GetDataCriacao().ToString("dd/MM/yyyy")} \nData de Vencimento: {cotacao.Value.GetDataVencimento().ToString("dd/MM/yyyy")} \nComprador: {nome} \nStatus: {cotacao.Value.GetStatus()}\n");

                if (cotacao.Value.GetListaProdutos().Count > 0)
                {
                    Console.Write("Itens:");
                    foreach (Produto produto in cotacao.Value.GetListaProdutos())
                    {
                        Console.WriteLine($"\tID Produto: {produto.GetIdProduto()} \n\tDescrição: {produto.GetDescricao()} \n\tValor: {produto.GetValor()} \n\tQuantidade: {produto.GetEstoque()}\n");
                    }
                }
                else
                {
                    Console.Write("Não há itens nesta cotação\n");
                }
                Console.WriteLine();
            }
        }

        public void AlterarStatusCotacao()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR STATUS -=-=-=-=-=-=-=-=-\n");
            ExibirCotacoes();

            while (true)
            {
                Console.Write("Digite o ID da cotação a ter o status alterado ou 'C' para cancelar a operação: ");
                string idCotacao = Console.ReadLine();

                if (idCotacao.ToUpper() == "C")
                {
                    Console.Clear();
                    Console.WriteLine("Operação cancelada pelo usuário.\n");
                    return;
                }

                if (listaCotacao.ContainsKey(idCotacao))
                {
                    Console.Clear();
                    Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR STATUS -=-=-=-=-=-=-=-=-\n");
                    Console.Write("O que deseja fazer: \n\n\t[1] Confirmar Cotação \n\t[2] Recusar Cotação \n\nResposta: ");
                    string resposta = Console.ReadLine();

                    if (resposta == "1")
                    {
                        listaCotacao[idCotacao].AlterarStatus(2);
                    }
                    else if (resposta == "2")
                    {
                        listaCotacao[idCotacao].AlterarStatus(3);
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Resposta inválida.\n");
                        return;
                    }

                    Console.Clear();
                    Console.WriteLine("Status alterado com sucesso!\n");
                    return;
                }
                else
                {
                    Console.WriteLine("ID não encontrado. Tente novamente.\n");
                }
            }
        }


        public void AlterarDataVencimento()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR DATA LIMITE -=-=-=-=-=-=-=-=-\n");
            ExibirCotacoes();

            string idCotacao;
            do
            {
                Console.Write("Digite o ID da cotação a ter a data de validade alterada ou digite 'C' para cancelar: ");
                idCotacao = Console.ReadLine();

                if (idCotacao.ToUpper() == "C")
                {
                    Console.Clear();
                    Console.WriteLine("Operação cancelada pelo usuário.");
                    return;
                }

                if (listaCotacao.ContainsKey(idCotacao))
                {
                    DateTime data;
                    Console.Clear();
                    Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR DATA LIMITE -=-=-=-=-=-=-=-=-\n");
                    Console.WriteLine($"Data de Vencimento atual: {listaCotacao[idCotacao].GetDataVencimento().ToString("dd/MM/yyyy")}");
                    do
                    {
                        Console.Write("Digite a nova data limite: ");

                        try
                        {
                            data = DateTime.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Valor inválido. Tente novamente.\n");
                            continue;
                        }

                        if (data < listaCotacao[idCotacao].GetDataCriacao())
                        {
                            Console.WriteLine("A data de vencimento não pode ser anterior à data de criação.\n");
                        }
                        else
                        {
                            Console.Clear();
                            listaCotacao[idCotacao].AlterarDataVencimento(data);
                            Console.WriteLine("Data de Vencimento alterada com sucesso!\n");
                            return;
                        }
                    } while (true);
                }
                else
                {
                    Console.WriteLine("\nID não encontrado. Tente novamente.\n");
                }
            } while (true);
        }
    }
}
