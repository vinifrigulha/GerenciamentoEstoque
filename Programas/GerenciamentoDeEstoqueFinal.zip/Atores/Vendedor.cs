﻿using GerenciamentoDeEstoque.Objetos.Estoque;
using GerenciamentoDeEstoque.Objetos.Venda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace GerenciamentoDeEstoque.Atores
{
    public class Vendedor : Funcionario
    {
        private List<Pedido> pedidos = new List<Pedido>();
        private List<Produto> estoque = new List<Produto>();
        private static Random random = new Random();
        public Vendedor(string nome, string cpf, string email, string login, string senha, string endereco, string telefone)
            : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'V';
            id = tipoFuncionario + "-" + id;
            CriarEstoque();
            CriarPedidos();
        }

        // Interface
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO VENDEDOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Criar Pedido");
                Console.WriteLine("\t[2] Exibir Pedidos");
                Console.WriteLine("\t[3] Visualizar Perfil");
                Console.WriteLine("\t[4] Alterar Senha");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaV;
                try
                {
                    respostaV = int.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaV = -1;
                }

                Console.Clear();
                switch (respostaV)
                {
                    case 1:
                        CriarPedido();
                        break;

                    case 2:
                        Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE PEDIDOS -=-=-=-=-=-=-=-=-\n");
                        ExibirPedidos();
                        Console.Write("Aperte 'Enter' para continuar...");
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case 3:
                        VisualizarDados();
                        break;

                    case 4:
                        AlterarSenha();
                        break;

                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }

        public void CriarPedido()
        {
            ExibirEstoque();

            // Criar um novo pedido
            Pedido novoPedido = new Pedido();

            do
            {
                Console.Write("Digite o ID do produto que deseja adicionar ao pedido (ou 'C' para finalizar): ");
                string idProduto = Console.ReadLine();

                if (idProduto.ToUpper() == "C")
                {
                    Console.Clear();
                    Console.WriteLine("Pedido criado com sucesso!\n");
                    return;
                }

                // Verificar se o produto está no estoque
                Produto produtoSelecionado = estoque.Find(produto => produto.GetIdProduto() == idProduto);

                if (produtoSelecionado != null)
                {
                    novoPedido.AdicionarItem(produtoSelecionado);
                    Console.WriteLine($"Produto '{produtoSelecionado.GetDescricao()}' adicionado ao pedido.\n");
                }
                else
                {
                    Console.WriteLine("ID do produto não encontrado. Tente novamente.\n");
                }

            } while (true);
        }

        public void ExibirPedidos()
        {
            foreach (Pedido pedido in pedidos)
            {
                Console.WriteLine($"ID do Pedido: {pedido.GetIdPedido()} \nData de Criação: {pedido.GetDataCriacao().ToString("dd/MM/yyyy")}");
            }
        }

        public void CriarPromocao()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- CRIAR PROMOÇÃO -=-=-=-=-=-=-=-=-\n");
            ExibirEstoque();

            Console.Write("Digite o ID do produto para criar a promoção: ");
            string idProdutoPromocao = Console.ReadLine();

            Produto produtoParaPromocao = estoque.Find(produto => produto.GetIdProduto() == idProdutoPromocao);

            if (produtoParaPromocao != null)
            {
                Console.Write($"Produto selecionado: {produtoParaPromocao.GetDescricao()} \n");
                Console.Write("Digite o percentual de desconto para a promoção (ex: 10 para 10%): ");

                if (decimal.TryParse(Console.ReadLine(), out decimal percentualDesconto))
                {
                    produtoParaPromocao.AplicarDesconto(percentualDesconto);
                    Console.Clear();
                    Console.WriteLine("Promoção criada com sucesso!\n");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Percentual de desconto inválido. A promoção não foi criada.\n");
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("ID do produto não encontrado. A promoção não foi criada.\n");
            }
        }

        public void ReporEstoque()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- REPOR ESTOQUE -=-=-=-=-=-=-=-=-\n");
            ExibirEstoque();

            Console.Write("Digite o ID do produto para repor o estoque: ");
            string idProdutoReposicao = Console.ReadLine();

            Produto produtoParaReposicao = estoque.Find(produto => produto.GetIdProduto() == idProdutoReposicao);

            if (produtoParaReposicao != null)
            {
                Console.Write($"Produto selecionado: {produtoParaReposicao.GetDescricao()} \n");
                Console.Write("Digite a quantidade a ser adicionada ao estoque: ");

                if (int.TryParse(Console.ReadLine(), out int quantidadeReposicao) && quantidadeReposicao > 0)
                {
                    produtoParaReposicao.AdicionarEstoque(quantidadeReposicao);
                    Console.Clear();
                    Console.WriteLine("Estoque reposto com sucesso!\n");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Quantidade inválida. O estoque não foi reposto.\n");
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("ID do produto não encontrado. O estoque não foi reposto.\n");
            }
        }


        public void ExibirEstoque()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE PRODUTOS NO ESTOQUE -=-=-=-=-=-=-=-=-\n");

            foreach (Produto produto in estoque)
            {
                Console.WriteLine($"ID Produto: {produto.GetIdProduto()} \nDescrição: {produto.GetDescricao()} \nValor: {produto.GetValor()} \nEstoque: {produto.GetEstoque()}\n");
            }
        }


        public void CriarPedidos()
        {
            // Gera um número aleatório de pedidos (entre 3 e 5, por exemplo)
            int numeroPedidos = random.Next(3, 6);

            for (int i = 0; i < numeroPedidos; i++)
            {
                Pedido novoPedido = new Pedido();
                pedidos.Add(novoPedido);
            }
        }

        private void CriarEstoque()
        {
            // Adicione produtos à lista de estoque conforme necessário
            Produto produto1 = new Produto("Maçã", 2.5m, "2023-12-31", 100, "Unidade", "Setor de Frutas");
            Produto produto2 = new Produto("Camiseta", 29.99m, "2023-12-31", 50, "Peça", "Setor de Vestuário");
            Produto produto3 = new Produto("Caderno", 8.99m, "2024-12-31", 80, "Unidade", "Setor de Papelaria");

            // Adicione os produtos à lista de estoque
            estoque.Add(produto1);
            estoque.Add(produto2);
            estoque.Add(produto3);
        }
    }

}
