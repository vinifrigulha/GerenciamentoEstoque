﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Objetos.Estoque
{
    public class Produto
    {
        private string idProduto;
        private string descricao;
        private decimal valor;
        private DateTime dataPrimeiroCadastro;
        private string dataValidade;
        private int estoque;
        private string unidadeVenda;
        private string localizacaoEstoque;
        private int diasParado;
        private static Random random = new Random();

        public Produto(string descricao, decimal valor, string dataValidade, int estoque, string unidadeVenda, string localizacaoEstoque, int diasParado = 0)
        {
            SetIdProduto();
            this.descricao = descricao;
            this.valor = valor;
            dataPrimeiroCadastro = DateTime.Today;
            this.dataValidade = dataValidade;
            this.estoque = estoque;
            this.unidadeVenda = unidadeVenda;
            this.localizacaoEstoque = localizacaoEstoque;
            this.diasParado = diasParado;
        }

        public void ExibirDetalhes()
        {
            Console.WriteLine($"ID Produto: {GetIdProduto()} \nDescrição: {GetDescricao()} \nValor: {GetValor()} \nData de Primeiro Cadastro: {GetDataPrimeiroCadastro().ToString("dd/MM/yyyy")}\n" +
                              $"Data de Validade: {GetDataValidade()} \nEstoque: {GetEstoque()} \nUnidade de Venda: {GetUnidadeVenda()} \nLocalização no Estoque: {GetLocalizacaoEstoque()}\n" +
                              $"Dias Parado: {GetDiasParados()}\n");
        }

        // Método para aplicar desconto ao valor do produto
        public void AplicarDesconto(decimal percentualDesconto)
        {
            if (percentualDesconto >= 0 && percentualDesconto <= 100)
            {
                decimal fatorDesconto = 1 - (percentualDesconto / 100);
                valor *= fatorDesconto;
                Console.WriteLine($"Desconto de {percentualDesconto}% aplicado ao produto '{descricao}'. Novo valor: {valor:C}\n");
            }
            else
            {
                Console.WriteLine("Percentual de desconto inválido. O desconto não foi aplicado.\n");
            }
        }

        // Método para adicionar quantidade ao estoque
        public void AdicionarEstoque(int quantidade)
        {
            if (quantidade > 0)
            {
                estoque += quantidade;
                Console.WriteLine($"Estoque do produto '{descricao}' aumentado em {quantidade} unidades. Novo estoque: {estoque}\n");
            }
            else
            {
                Console.WriteLine("Quantidade inválida. O estoque não foi alterado.\n");
            }
        }


        // Gets
        public string GetIdProduto() { return idProduto; }
        public string GetDescricao() {  return descricao; }
        public decimal GetValor() {  return valor; }
        public DateTime GetDataPrimeiroCadastro() {  return dataPrimeiroCadastro; }
        public string GetDataValidade() {  return dataValidade; }
        public int GetEstoque() {  return estoque; }
        public string GetUnidadeVenda() {  return unidadeVenda; }
        public string GetLocalizacaoEstoque() { return localizacaoEstoque; }
        public int GetDiasParados() { return diasParado; }

        // Sets
        private void SetIdProduto()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idProduto = "PROD-" + numeroAleatorio.ToString("000000");
        }
        public void SetValor(decimal novoValor) { valor = novoValor; }
        public void SetLocalizacaoEstoque(string localizacaoEstoque) { this.localizacaoEstoque = localizacaoEstoque; }
        public void SetUnidadeVenda(string unidadeVenda) { this.unidadeVenda = unidadeVenda; }
    }
}
