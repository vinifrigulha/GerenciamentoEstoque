﻿using GerenciamentoDeEstoque.Atores;
using GerenciamentoDeEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Objetos.Venda
{
    public class Pedido
    {
        // Listas
        private List<Produto> produtos = new List<Produto>();
        private Dictionary<int, Produto> produtosDiaADia = new Dictionary<int, Produto>();

        // Atributos
        private string idPedido;
        private DateTime dataCriacao;
        private static Random random = new Random();

        public Pedido()
        {
            SetIdPedido();
            InicializarProdutosDiaADia();
            dataCriacao = DateTime.Today;
            produtos = CriarListaProduto();
        }

        private void InicializarProdutosDiaADia()
        {
            // Criação de 20 produtos do dia a dia
            for (int i = 1; i <= 20; i++)
            {
                Produto produto = new Produto($"Produto {i}", 10.0m + i, "2023-12-31", 50 + i, "Unidade", $"Estoque {i + 1}");
                produtosDiaADia.Add(i, produto);
            }
        }

        private List<Produto> CriarListaProduto()
        {
            List<Produto> listaProdutosPedido = new List<Produto>();

            // Seleciona aleatoriamente entre 5 e 10 produtos do dicionário
            int quantidadeProdutos = random.Next(5, 11);

            for (int i = 0; i < quantidadeProdutos; i++)
            {
                int indiceProduto = random.Next(1, 21);
                Produto produtoSelecionado = produtosDiaADia[indiceProduto];
                listaProdutosPedido.Add(produtoSelecionado);
            }

            return listaProdutosPedido;
        }

        public void AdicionarItem(Produto produto)
        {
            produtos.Add(produto);
        }

        // Gets
        public string GetIdPedido() { return idPedido; }
        public DateTime GetDataCriacao() { return dataCriacao; }

        // Sets
        private void SetIdPedido()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idPedido = "PED-" + numeroAleatorio.ToString("000000");
        }
    }
}
