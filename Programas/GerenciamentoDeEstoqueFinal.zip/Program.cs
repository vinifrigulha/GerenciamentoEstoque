﻿using GerenciamentoDeEstoque.Atores;
using System.Data;
using System.Text.RegularExpressions;

namespace GerenciamentoDeEstoque
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int i = -1;
            Administrador administrador = CriarAdminPadrao();

            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- STOCKFLOW -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Login");
                Console.WriteLine("\t[0] Sair\n");
                Console.Write("Resposta: ");

                int resposta;
                try
                {
                    resposta = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    resposta = -1;
                }

                Console.Clear();
                switch (resposta)
                {
                    case 1:
                        FazerLogin(administrador);
                        break;

                    case 0:
                        i = 0;
                        Console.WriteLine("\nVocê escolheu sair. Até breve!");
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (i != 0);

        }

        // Fazer Login
        public static void FazerLogin(Administrador administrador)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- LOGIN -=-=-=-=-=-=-=-=-\n");
            Console.Write("Digite seu login: ");
            string login = Console.ReadLine();
            Console.Write("Digite sua senha: ");
            string senha = Console.ReadLine();

            Console.Clear();
            if (administrador.GetLista().Any(f => f.GetLogin() == login && f.GetSenha() == senha))
            {
                var funcionario = administrador.GetLista().First(f => f.GetLogin() == login && f.GetSenha() == senha);
                funcionario.Login(login, senha);
                funcionario.Menu();
            }
            else
            {
                Console.WriteLine("Login falhou. Verifique suas credenciais.\n");
            }
        }

        // Criar Administrador Padrão
        public static Administrador CriarAdminPadrao()
        {
            Administrador admin = new Administrador("Administrador", "00000000000", "admin@admin.com", "admin", "admin", "Endereço do Administardor", "(99) 99999-9999");
            return admin;
        }

    }
}