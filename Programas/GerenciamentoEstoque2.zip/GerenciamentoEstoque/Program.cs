﻿using GerenciamentoEstoque.Atores;
using GerenciamentoEstoque.Atores.Internos;

namespace GerenciamentoEstoque
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Seu nome: ");
            string nome = Console.ReadLine();
            Console.Write("\nSeu CPF: ");
            string cpf = Console.ReadLine();
            Console.Write("\nSeu e-mail: ");
            string email = Console.ReadLine();
            Console.Write("\nSeu login: ");
            string login = Console.ReadLine();
            Console.Write("\nSua senha: ");
            string senha = Console.ReadLine();
            Console.Write("\nSeu endereço: ");
            string endereco = Console.ReadLine();
            Console.Write("\nSeu telefone (se não tiver, aperte 'Enter'): ");
            string telefone = Console.ReadLine();

            Comprador c1 = new Comprador(nome, cpf, email, login, senha, endereco, telefone);

            c1.Login();

            c1.CriarCotacao();
            c1.CriarCotacao();
            c1.CriarCotacao();
            c1.CriarCotacao();

            c1.AlterarStatusCotacao();
            c1.ExibirCotacoes();

            c1.Logoff();
        }
    }
}