﻿using GerenciamentoEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoEstoque.Atores.Internos
{
    public class Comprador : Funcionario
    {
        Dictionary<string, Cotacao> listaCotacao = new Dictionary<string, Cotacao>();
        public Comprador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone = "")
            : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'C';
            id = tipoFuncionario + "-" + id;
        }

        // Cotações
        public void CriarCotacao()
        {
            Cotacao cotacao = new Cotacao(id);
            listaCotacao.Add(cotacao.GetIdCotacao(), cotacao);
        }
        public void ExibirCotacoes()
        {
            foreach (KeyValuePair<string, Cotacao> cotacao in listaCotacao)
            {
                Console.Write($"\nID Cotação: {cotacao.Key} \nComprador: {nome} - {cotacao.Value.GetIdComprador()} \nStatus: {cotacao.Value.GetStatus()}\n");
            }
        }
        public void AlterarStatusCotacao()
        {
            ExibirCotacoes();
            Console.Write("\nDigite o ID da cotação a ter o status alterado: ");
            string idCotacao = Console.ReadLine();

            if (listaCotacao.ContainsKey(idCotacao))
            {
                Console.Write("\nO que deseja fazer: \n[1] Confirmar Cotação \n[2] Recusar Cotação \n\nResposta: ");
                string resposta = Console.ReadLine();
                if (resposta == "1")
                {
                    listaCotacao[idCotacao].AlterarStatus(2);
                }
                else if (resposta == "2")
                {
                    listaCotacao[idCotacao].AlterarStatus(3);
                }
                else
                {
                    Console.Write("\nResposta inválida.");
                    return;
                }
                Console.Write($"\nNovo Status da Cotação {listaCotacao[idCotacao].GetIdCotacao()} - {listaCotacao[idCotacao].GetStatus()}\n");
                return;
            }
            Console.WriteLine("\nID não encontrado.");

        }
    }
}
