﻿using GerenciamentoEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoEstoque.Atores.Externos
{
    public class Fornecedor
    {
        private string idFornecedor;
        private string nomeFornecedor;
        private static Random random = new Random();

        public string GetId() { return idFornecedor; }
        public string GetNome() { return nomeFornecedor; }

        private void SetId()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idFornecedor = "FOR-" + numeroAleatorio.ToString("000000");
        }

        public void SetNome(string nomeFornecedor) { this.nomeFornecedor = nomeFornecedor; }

        /*public Cotacao ResponderCotacao(string idCotacao)
        {

        }
        */

        public void EnviarProdutos()
        {

        }

        public void ReceberNotificaçãoAlmoxarife()
        {

        }
    }
}
