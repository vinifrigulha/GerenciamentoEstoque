﻿using GerenciamentoDeEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Internos
{
    public class Comprador : Funcionario
    {
        Dictionary<string, Cotacao> listaCotacao = new Dictionary<string, Cotacao>();
        public Comprador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone)
            : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'C';
            id = tipoFuncionario + "-" + id;
        }

        // Métodos do Comprador
        public void CriarCotacao()
        {
            Cotacao cotacao = new Cotacao(id);
            listaCotacao.Add(cotacao.GetIdCotacao(), cotacao);
            Console.Clear();
            Console.WriteLine("Cotação criada com sucesso!\n");
        }
        public void ExibirCotacoes()
        {
            foreach (KeyValuePair<string, Cotacao> cotacao in listaCotacao)
            {
                Console.Write($"\nID Cotação: {cotacao.Key} \nComprador: {nome} - {cotacao.Value.GetIdComprador()} \nStatus: {cotacao.Value.GetStatus()}\n");
            }
        }
        public void AlterarStatusCotacao()
        {
            ExibirCotacoes();
            Console.Write("\nDigite o ID da cotação a ter o status alterado: ");
            string idCotacao = Console.ReadLine();

            if (listaCotacao.ContainsKey(idCotacao))
            {
                Console.Write("\nO que deseja fazer: \n[1] Confirmar Cotação \n[2] Recusar Cotação \n\nResposta: ");
                string resposta = Console.ReadLine();
                if (resposta == "1")
                {
                    listaCotacao[idCotacao].AlterarStatus(2);
                }
                else if (resposta == "2")
                {
                    listaCotacao[idCotacao].AlterarStatus(3);
                }
                else
                {
                    Console.Write("\nResposta inválida.");
                    return;
                }
                Console.Write($"\nNovo Status da Cotação {listaCotacao[idCotacao].GetIdCotacao()} - {listaCotacao[idCotacao].GetStatus()}\n");
                return;
            }
            Console.WriteLine("\nID não encontrado.");

        }

        // Interface
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO COMPRADOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Criar Cotação");
                Console.WriteLine("\t[2] Exibir Cotações");
                Console.WriteLine("\t[3] Alterar Status da Cotação");
                Console.WriteLine("\t[4] Visualizar Perfil");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaC;
                try
                {
                    respostaC = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaC = -1;
                }

                Console.Clear();
                switch (respostaC)
                {
                    case 1:
                        CriarCotacao();
                        break;

                    case 2:
                        ExibirCotacoes();
                        break;

                    case 3:
                        AlterarStatusCotacao();
                        break;

                    case 4:
                        Console.WriteLine("PERFIL\n");
                        break;

                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }
    }
}
