﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Internos
{
    public class Administrador : Funcionario
    {
        private List<Funcionario> funcionarios;
        public Administrador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone) : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'A';
            id = tipoFuncionario + "-" + id;
            funcionarios = new List<Funcionario> { this };
        }

        // Método
        public void Cadastrar()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- CADASTRO -=-=-=-=-=-=-=-=-\n");
            string nome = LerNome();
            string cpf = LerCPF(11);
            string email = LerEmail();
            string login = LerLogin(8);
            string senha = LerSenha(8);
            string endereco = LerEndereco();
            string telefone = LerTelefone();

            Funcionario funcionario = new Funcionario(nome, cpf, email, login, senha, endereco, telefone);

            char tipoFuncionario = LerTipoFuncionario();
            if (tipoFuncionario == 'C')
            {
                Comprador comprador = funcionario.CriarComprador();
                funcionarios.Add(comprador);
            }
            else if (tipoFuncionario == 'V')
            {
                Vendedor vendedor = funcionario.CriarVendedor();
                funcionarios.Add(vendedor);
            }
            else
            {
                Administrador administrador = funcionario.CriarAdministrador();
                funcionarios.Add(administrador);
            }

            Console.Clear();
            Console.WriteLine("Cadastro efetuado com sucesso!\n");
        }

        // Tratamentos de Erro do Cadastro
        private string LerNome()
        {
            string input;
            do
            {
                Console.Write("Seu nome: ");
                input = Console.ReadLine();
                if (funcionarios.Any(f => f.GetNome() == input))
                {
                    Console.WriteLine("Nome já cadastrado. Por favor, use apenas letras e espaços e escolha um nome único.\n");
                }
                else if (!Regex.IsMatch(input, @"^[a-zA-Z\s]+$"))
                {
                    Console.WriteLine("Nome inválido. Por favor, use apenas letras e espaços.\n");
                }
            } while (!Regex.IsMatch(input, @"^[a-zA-Z\s]+$") || funcionarios.Any(f => f.GetNome() == input));
            return input;
        }

        private string LerCPF(int comprimento)
        {
            string input;
            do
            {
                Console.Write("Seu CPF - só dígitos numéricos: ");
                input = Console.ReadLine();
                if (!Regex.IsMatch(input, @"^\d{" + comprimento + "}$"))
                {
                    Console.WriteLine($"Entrada inválida. Por favor, use exatamente {comprimento} dígitos numéricos.\n");
                }
                else if (funcionarios.Any(f => f.GetCPF() == input))
                {
                    Console.WriteLine("Erro: CPF já cadastrado. Tente novamente.\n");
                }
            } while (!Regex.IsMatch(input, @"^\d{" + comprimento + "}$") || funcionarios.Any(f => f.GetCPF() == input));
            return input;
        }
        private string LerEmail()
        {
            string input;
            do
            {
                Console.Write("Seu e-mail: ");
                input = Console.ReadLine();
                if (!Regex.IsMatch(input, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    Console.WriteLine("E-mail inválido. Por favor, insira um e-mail válido.\n");
                }
                else if (funcionarios.Any(f => f.GetEmail() == input))
                {
                    Console.WriteLine("E-mail já cadastrado. Por favor, insira um e-mail único.\n");
                }
            } while (!Regex.IsMatch(input, @"^[^@\s]+@[^@\s]+\.[^@\s]+$") || funcionarios.Any(f => f.GetEmail() == input));
            return input;
        }
        private string LerLogin(int tamanhoMinimo)
        {
            string input;
            do
            {
                Console.Write("Seu login (no mínimo 8 dígitos): ");
                input = Console.ReadLine();
                if (input.Length < tamanhoMinimo)
                {
                    Console.WriteLine($"Entrada inválida. A entrada deve ter pelo menos {tamanhoMinimo} caracteres. Tente novamente.\n");
                }
                else if (funcionarios.Any(f => f.GetLogin() == input))
                {
                    Console.WriteLine("Erro: Login já cadastrado. Tente novamente.\n");
                }
            } while (funcionarios.Any(f => f.GetLogin() == input) || input.Length < tamanhoMinimo);
            return input;
        }

        private string LerSenha(int tamanhoMinimo)
        {
            string input;
            do
            {
                Console.Write("Sua senha (no mínimo 8 dígitos): ");
                input = Console.ReadLine();
                if (input.Length < tamanhoMinimo)
                {
                    Console.WriteLine($"Entrada inválida. A entrada deve ter pelo menos {tamanhoMinimo} caracteres.\n");
                }
            } while (input.Length < tamanhoMinimo);
            return input;
        }

        private string LerEndereco()
        {
            string input;
            do
            {
                Console.Write("Seu endereço: ");
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Entrada inválida. O campo não pode estar vazio.\n");
                }
            } while (string.IsNullOrWhiteSpace(input));
            return input;
        }

        private string LerTelefone()
        {
            string input;
            do
            {
                Console.Write("Para o telefone, use um dos formatos a seguir: \n\t[1] (XX) XXXXX-XXXX \n\t[2] (XX) XXXX-XXXX \nSeu telefone: ");
                input = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(input) && !Regex.IsMatch(input, @"^\(\d{2}\) \d{4,5}-\d{4}$"))
                {
                    Console.WriteLine("Número de telefone inválido. Use o formato (XX) XXXXX-XXXX ou (XX) XXXX-XXXX.\n");
                }
                else if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Entrada inválida. O campo não pode estar vazio.\n");
                }
            } while (string.IsNullOrWhiteSpace(input) || !Regex.IsMatch(input, @"^\(\d{2}\) \d{4,5}-\d{4}$"));
            return input;
        }
        private char LerTipoFuncionario()
        {
            char input;
            bool opcaoValida;

            do
            {
                Console.Write("Escolha um dos cargos abaixo para finalizar o cadastro: \n\t[1] Administrador \n\t[2] Comprador \n\t[3] Vendedor \n\nOpção: ");
                opcaoValida = char.TryParse(Console.ReadLine(), out input);

                if (!opcaoValida || (input != '1' && input != '2' && input !=  '3'))
                {
                    Console.WriteLine("Opção inválida. Por favor, escolha '1' para Administrador, '2' para Comprador ou '3' para Vendedor.\n");
                }

            } while (!opcaoValida || (input != '1' && input != '2' && input != '3'));

            return (input == '1') ? 'A' : (input == '2') ? 'C' : 'V';
        }

        // Get
        public List<Funcionario> GetLista() { return funcionarios; }
        
        // Interface
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO ADMINISTRADOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Cadastrar Funcionários");
                Console.WriteLine("\t[2] Exibir Funcionários");
                Console.WriteLine("\t[3] Excluir Funcionários");
                Console.WriteLine("\t[4] Visualizar Perfil");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaC;
                try
                {
                    respostaC = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaC = -1;
                }

                Console.Clear();
                switch (respostaC)
                {
                    case 1:
                        Cadastrar();
                        break;

                    case 2:
                        //ExibirFuncionarios();
                        break;

                    case 3:
                        //DeletarFuncionario();
                        break;

                    case 4:
                        Console.WriteLine("PERFIL\n");
                        break;

                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }
    }
}
