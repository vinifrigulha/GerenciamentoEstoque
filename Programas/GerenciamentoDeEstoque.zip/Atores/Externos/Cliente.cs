﻿using GerenciamentoDeEstoque.Objetos.Venda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Externos
{
    public class Cliente
    {
        private string idCliente;
        private string nomeCliente;
        private static Random random = new Random();

        public string GetId() { return idCliente; }
        public string GetNome() { return nomeCliente; }

        private void SetId()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idCliente = "CLI-" + numeroAleatorio.ToString("000000");
        }
        public void SetNome(string nomeCliente) { this.nomeCliente = nomeCliente; }

        public void ResponderVendedor(string idVendedor)
        {
        }

        public void Criarpedido()
        {

        }

        public void CancelarPedido(string idPedido)
        {

        }

        /*public Pedido EnviarPedido(string idPedido)
        {
        }
        */



    }
}
