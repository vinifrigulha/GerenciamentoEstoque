﻿using GerenciamentoDeEstoque.Atores.Internos;
using GerenciamentoDeEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Objetos.Venda
{
    public class Pedido
    {
        // Listas

        // Atributos
        private string idCotacao;
        private string idVendedor;
        private DateTime dataCriacao;
        private static Random random = new Random();

        // Gets
        public string GetIdCotacao() { return idCotacao; }
        public string GetIdComprador() { return idVendedor; }


        // Sets
        private void SetIdCotacao()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idCotacao = "PED-" + numeroAleatorio.ToString("000000");
        }
    }
}
