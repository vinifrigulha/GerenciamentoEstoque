﻿using GerenciamentoDeEstoque.Atores.Externos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Objetos.Estoque
{
    public class Cotacao
    {
        // Listas
        List<Fornecedor> listaFornecedores = new List<Fornecedor>();
        List<Produto> listaProdutos = new List<Produto>();
        private static Dictionary<int, string> statusCotacao = new Dictionary<int, string>
        {
            {1, "Em andamento..." },
            {2, "Confirmada" },
            {3, "Recusada" },
            {4, "Vencida" }
        };

        // Atributos
        private string idCotacao;
        private string idComprador;
        private int status;
        private DateTime dataCriacao;
        private DateTime dataVencimento;
        private static Random random = new Random();

        public Cotacao(string idComprador)
        {
            SetIdCotacao();
            this.idComprador = idComprador;
            status = 1;
            dataCriacao = DateTime.Today;
            dataVencimento = dataCriacao.AddDays(15);
        }

        // Método
        public void AlterarStatus(int novoStatus)
        {
            if (DateTime.Today > dataVencimento && status == 1)
            {
                status = 4;
                return;
            }
            status = novoStatus;
        }

        public void AlterarDataVencimento(DateTime dataVencimento)
        {
            this.dataVencimento = dataVencimento;
        }

        // Gets
        public string GetIdCotacao() { return idCotacao; }
        public string GetIdComprador() { return idComprador; }
        public string GetStatus() { return statusCotacao[status]; }
        public DateTime GetDataCriacao() {  return dataCriacao; }
        public DateTime GetDataVencimento() {  return dataVencimento; }


        // Sets
        private void SetIdCotacao()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            idCotacao = "COT-" + numeroAleatorio.ToString("000000");
        }
    }
}
