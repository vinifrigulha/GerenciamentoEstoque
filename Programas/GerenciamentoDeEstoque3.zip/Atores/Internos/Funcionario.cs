﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Internos
{
    public class Funcionario
    {
        // Atributos
        protected string id;
        protected string nome;
        protected string cpf;
        protected string email;
        protected string login;
        protected string senha;
        protected string endereco;
        protected string telefone;
        protected char tipoFuncionario;
        protected bool estaLogado;
        private static Random random = new Random();

        // Construtor
        public Funcionario(string nome, string cpf, string email, string login, string senha, string endereco, string telefone)
        {
            SetId();
            this.nome = nome;
            this.cpf = cpf;
            this.email = email;
            this.login = login;
            this.senha = senha;
            this.endereco = endereco;
            this.telefone = telefone;
            estaLogado = false;
        }
        // Métodos para criar instâncias especializadas
        public virtual Comprador CriarComprador()
        {
            return new Comprador(nome, cpf, email, login, senha, endereco, telefone);
        }

        public virtual Vendedor CriarVendedor()
        {
            return new Vendedor(nome, cpf, email, login, senha, endereco, telefone);
        }

        public virtual Administrador CriarAdministrador()
        {
            return new Administrador(nome, cpf, email, login, senha, endereco, telefone);
        }

        // Métodos
        public bool Login(string login, string senha)
        {
            estaLogado = true;
            Console.WriteLine("Login realizado com sucesso!\n");
            return this.login == login && this.senha == senha;
        }
        public void Logoff()
        {
            estaLogado = false;
            Console.WriteLine("Você saiu. Até mais! :)\n");
        }

        // Menu
        public virtual void Menu()
        {
        }

        // Visualizar Dados
        protected void VisualizarDados()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- DADOS DO PERFIL -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Nome: {GetNome()}");
            Console.WriteLine($"ID: {GetId()}");
            Console.WriteLine($"Cargo: {this.GetType().Name}");
            Console.WriteLine($"CPF: {GetCPF()}");
            Console.WriteLine($"E-mail: {GetEmail()}");
            Console.WriteLine($"Endereço: {GetEndereco()}");
            Console.WriteLine($"Telefone: {GetTelefone()}\n");
            Console.Write("Aperte 'Enter' para voltar...");
            Console.ReadLine();
            Console.Clear();
        }

        // Alterar Senha
        public void AlterarSenha()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR SENHA -=-=-=-=-=-=-=-=-\n");
            Console.Write("Digite sua senha atual: ");
            string senhaAntiga = Console.ReadLine();
            while (senhaAntiga != senha)
            {
                Console.WriteLine("Senha incorreta! Tente novamente.\n");
                Console.Write("Digite sua senha atual: ");
                senhaAntiga = Console.ReadLine();
            }

            Console.Write("Digite sua nova senha: ");
            string senhaNova = Console.ReadLine();
            Console.Write("Repita sua nova senha: ");
            string senhaConfirmacao = Console.ReadLine();

            while (senhaNova != senhaConfirmacao)
            {
                Console.WriteLine("As senhas não coincidem! Tente novamente.\n");
                Console.Write("Digite sua nova senha: ");
                senhaNova = Console.ReadLine();
                Console.Write("Repita sua nova senha: ");
                senhaConfirmacao = Console.ReadLine();
            }

            senha = senhaNova;
            Console.Clear();
            Console.WriteLine("Senha alterada com sucesso!\n");
        }

        // Gets
        public string GetId() { return id; }
        public string GetNome() { return nome; }
        public string GetCPF() { return cpf; }
        public string GetEmail() { return email; }
        public string GetEndereco() { return endereco; }
        public string GetTelefone() { return telefone; }
        public string GetLogin() { return login; }
        public string GetSenha() { return senha; }
        public char GetTipoFuncionario() { return tipoFuncionario; }

        // Sets
        private void SetId()
        {
            int numeroAleatorio = random.Next(1, 1000000);
            id = numeroAleatorio.ToString("000000");
        }
        public void SetCPF(string cpf) 
        {
            Console.Clear();
            this.cpf = cpf;
            Console.WriteLine("CPF alterado com sucesso!\n");
        }
        public void SetNome(string nome) 
        {
            Console.Clear();
            this.nome = nome;
            Console.WriteLine("Nome alterado com sucesso!\n");
        }
        public void SetEmail(string email) 
        {
            Console.Clear();
            this.email = email;
            Console.WriteLine("Email alterado com sucesso!\n");
        }
        public void SetEndereco(string endereco) 
        {
            Console.Clear();
            this.endereco = endereco;
            Console.WriteLine("Endereço alterado com sucesso!\n");
        }
        public void SetTelefone(string telefone) 
        {
            Console.Clear();
            this.telefone = telefone;
            Console.WriteLine("Telefone alterado com sucesso!\n");
        }
    }
}