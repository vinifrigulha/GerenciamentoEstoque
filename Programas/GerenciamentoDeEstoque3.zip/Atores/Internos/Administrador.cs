﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Internos
{
    public class Administrador : Funcionario
    {
        private List<Funcionario> funcionarios;
        public Administrador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone) : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'A';
            id = tipoFuncionario + "-" + id;
            funcionarios = new List<Funcionario> { this };
        }

        // Menu
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO ADMINISTRADOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Cadastrar Funcionários");
                Console.WriteLine("\t[2] Exibir Funcionários");
                Console.WriteLine("\t[3] Excluir Funcionários");
                Console.WriteLine("\t[4] Modificar Funcionário");
                Console.WriteLine("\t[5] Visualizar Perfil");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaC;
                try
                {
                    respostaC = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaC = -1;
                }

                Console.Clear();
                switch (respostaC)
                {
                    case 1:
                        Cadastrar();
                        break;

                    case 2:
                        ExibirFuncionarios();
                        if (funcionarios.Count - 1 > 0)
                        {
                            Console.Write("Pressione 'Enter' para continuar...");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        break;

                    case 3:
                        DeletarFuncionario();
                        break;

                    case 4:
                        ModificarFuncionario();
                        break;

                    case 5:
                        Perfil();
                        break;


                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }

        // Método
        public void Cadastrar()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- CADASTRO -=-=-=-=-=-=-=-=-\n");
            string nome = LerNome();
            string cpf = LerCPF(11);
            string email = LerEmail();
            string login = LerLogin(8);
            string senha = LerSenha(8);
            string endereco = LerEndereco();
            string telefone = LerTelefone();

            Funcionario funcionario = new Funcionario(nome, cpf, email, login, senha, endereco, telefone);

            char tipoFuncionario = LerTipoFuncionario();
            if (tipoFuncionario == 'C')
            {
                Comprador comprador = funcionario.CriarComprador();
                funcionarios.Add(comprador);
            }
            else if (tipoFuncionario == 'V')
            {
                Vendedor vendedor = funcionario.CriarVendedor();
                funcionarios.Add(vendedor);
            }
            else
            {
                Administrador administrador = funcionario.CriarAdministrador();
                funcionarios.Add(administrador);
            }

            Console.Clear();
            Console.WriteLine("Cadastro efetuado com sucesso!\n");
        }

        // Visualizar Funcionários
        public void ExibirFuncionarios()
        {
            if (!ContarFuncionarios()) return;

            int i = 0;

            Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE FUNCIONÁRIOS -=-=-=-=-=-=-=-=-\n");
            foreach (Funcionario funcionario in funcionarios)
            {
                if (i == 0)
                {
                    i++;
                    continue;
                }
                Console.WriteLine($"Funcionário #{i}:");
                Console.WriteLine($"Nome: {funcionario.GetNome()}");
                Console.WriteLine($"ID: {funcionario.GetId()}");
                Console.WriteLine($"Cargo: {funcionario.GetType().Name}\n");
                i++;
            }
        }

        // Deletar Funcionários
        public void DeletarFuncionario()
        {
            if (!ContarFuncionarios()) return;

            ExibirFuncionarios();

            do
            {
                Console.Write("Digite o ID do funcionário para deletar ou 'C' para cancelar: ");
                string id = Console.ReadLine().ToUpper();

                if (id == "C")
                {
                    Console.Clear();
                    Console.WriteLine("A operação de deletar funcionários foi cancelada.\n");
                    break;
                }

                Funcionario funcionarioParaRemover = funcionarios.FirstOrDefault(funcionario => funcionario.GetId() == id);

                if (funcionarioParaRemover != null)
                {
                    funcionarios.Remove(funcionarioParaRemover);
                    Console.Clear();
                    Console.WriteLine("O funcionário removido com sucesso.\n");
                    break;
                }
                else
                {
                    Console.WriteLine("Funcionário não foi identificado.\n");
                }

            } while (true);
        }

        // Modificar Funcionário
        public void ModificarFuncionario()
        {
            if (!ContarFuncionarios()) return;

            ExibirFuncionarios();

            do
            {
                Console.Write("Digite o ID do funcionário para modificar ou 'C' para cancelar: ");
                string id = Console.ReadLine().ToUpper();

                if (id == "C")
                {
                    Console.Clear();
                    Console.WriteLine("A operação de modificar funcionários foi cancelada.\n");
                    break;
                }

                Funcionario funcionarioParaModificar = funcionarios.FirstOrDefault(funcionario => funcionario.GetId() == id);

                if (funcionarioParaModificar != null)
                {
                    Console.Clear();
                    AlterarDadosFuncionario(funcionarioParaModificar);
                    break;
                }
                else
                {
                    Console.WriteLine("Funcionário não foi identificado.\n");
                }

            } while (true);
        }

        // Tratamentos de Erro do Cadastro
        public string LerNome()
        {
            string input;
            do
            {
                Console.Write("Novo Nome: ");
                input = Console.ReadLine();
                if (funcionarios.Any(f => string.Equals(f.GetNome(), input, StringComparison.OrdinalIgnoreCase)))
                {
                    Console.WriteLine("Nome já cadastrado. Por favor, use um nome único.\n");
                }
                else if (!Regex.IsMatch(input, @"^[\p{L}\s]+$"))
                {
                    Console.WriteLine("Nome inválido. Por favor, use apenas letras e espaços.\n");
                }
            } while (!Regex.IsMatch(input, @"^[\p{L}\s]+$") || funcionarios.Any(f => string.Equals(f.GetNome(), input, StringComparison.OrdinalIgnoreCase)));
            return input;
        }

        public string LerCPF(int comprimento)
        {
            string input;
            do
            {
                Console.Write("Novo CPF - só dígitos numéricos: ");
                input = Console.ReadLine();
                if (!Regex.IsMatch(input, @"^\d{" + comprimento + "}$"))
                {
                    Console.WriteLine($"Entrada inválida. Por favor, use exatamente {comprimento} dígitos numéricos.\n");
                }
                else if (funcionarios.Any(f => f.GetCPF() == input))
                {
                    Console.WriteLine("Erro: CPF já cadastrado. Tente novamente.\n");
                }
            } while (!Regex.IsMatch(input, @"^\d{" + comprimento + "}$") || funcionarios.Any(f => f.GetCPF() == input));
            return input;
        }
        public string LerEmail()
        {
            string input;
            do
            {
                Console.Write("Novo E-mail: ");
                input = Console.ReadLine();
                if (!Regex.IsMatch(input, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    Console.WriteLine("E-mail inválido. Por favor, insira um e-mail válido.\n");
                }
                else if (funcionarios.Any(f => f.GetEmail() == input))
                {
                    Console.WriteLine("E-mail já cadastrado. Por favor, insira um e-mail único.\n");
                }
            } while (!Regex.IsMatch(input, @"^[^@\s]+@[^@\s]+\.[^@\s]+$") || funcionarios.Any(f => f.GetEmail() == input));
            return input;
        }
        private string LerLogin(int tamanhoMinimo)
        {
            string input;
            do
            {
                Console.Write("Novo Login (no mínimo 8 dígitos): ");
                input = Console.ReadLine();
                if (input.Length < tamanhoMinimo)
                {
                    Console.WriteLine($"Entrada inválida. A entrada deve ter pelo menos {tamanhoMinimo} caracteres. Tente novamente.\n");
                }
                else if (funcionarios.Any(f => f.GetLogin() == input))
                {
                    Console.WriteLine("Erro: Login já cadastrado. Tente novamente.\n");
                }
            } while (funcionarios.Any(f => f.GetLogin() == input) || input.Length < tamanhoMinimo);
            return input;
        }

        private string LerSenha(int tamanhoMinimo)
        {
            string input;
            do
            {
                Console.Write("Nova Senha (no mínimo 8 dígitos): ");
                input = Console.ReadLine();
                if (input.Length < tamanhoMinimo)
                {
                    Console.WriteLine($"Entrada inválida. A entrada deve ter pelo menos {tamanhoMinimo} caracteres.\n");
                }
            } while (input.Length < tamanhoMinimo);
            return input;
        }

        public string LerEndereco()
        {
            string input;
            do
            {
                Console.Write("Novo Endereço: ");
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Entrada inválida. O campo não pode estar vazio.\n");
                }
            } while (string.IsNullOrWhiteSpace(input));
            return input;
        }

        public string LerTelefone()
        {
            string input;
            do
            {
                Console.Write("Para o telefone, use um dos formatos a seguir:\n \n\t[1] (XX) XXXXX-XXXX \n\t[2] (XX) XXXX-XXXX \n\nNovo Telefone: ");
                input = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(input) && !Regex.IsMatch(input, @"^\(\d{2}\) \d{4,5}-\d{4}$"))
                {
                    Console.WriteLine("Número de telefone inválido. Use o formato (XX) XXXXX-XXXX ou (XX) XXXX-XXXX.\n");
                }
                else if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Entrada inválida. O campo não pode estar vazio.\n");
                }
            } while (string.IsNullOrWhiteSpace(input) || !Regex.IsMatch(input, @"^\(\d{2}\) \d{4,5}-\d{4}$"));
            return input;
        }
        private char LerTipoFuncionario()
        {
            char input;
            bool opcaoValida;

            do
            {
                Console.Write("Escolha um dos cargos abaixo para finalizar o cadastro:\n \n\t[1] Administrador \n\t[2] Comprador \n\t[3] Vendedor \n\nCargo: ");
                opcaoValida = char.TryParse(Console.ReadLine(), out input);

                if (!opcaoValida || (input != '1' && input != '2' && input !=  '3'))
                {
                    Console.WriteLine("Opção inválida. Por favor, escolha '1' para Administrador, '2' para Comprador ou '3' para Vendedor.\n");
                }

            } while (!opcaoValida || (input != '1' && input != '2' && input != '3'));

            return (input == '1') ? 'A' : (input == '2') ? 'C' : 'V';
        }

        // Get
        public List<Funcionario> GetLista() { return funcionarios; }

        // Perfil
        public void Perfil()
        {
            int respPerfil;

            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- VISUALIZAR PERFIL -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Visualizar Dados");
                Console.WriteLine("\t[2] Alterar Seus Dados");
                Console.WriteLine("\t[0] Voltar\n");
                Console.Write("Resposta: ");

                try
                {
                    respPerfil = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respPerfil = -1;
                }

                Console.Clear();
                switch (respPerfil)
                {
                    case 1:
                        VisualizarDados();
                        break;

                    case 2:
                        AlterarDados();
                        break;

                    case 0:
                        break;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.\n");
                        break;
                }
            } while (respPerfil != 0);
        }

        private bool ContarFuncionarios() 
        { 
            if (funcionarios.Count - 1 == 0)
            {
                Console.WriteLine("Não há funcionários cadastrados no momento.\n");
                return false;
            }
            else
            {
                return true;
            }
        }

        // Alterar Dados
        public void AlterarDados()
        {
            int respAlterar;

            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR PERFIL -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Alterar Nome");
                Console.WriteLine("\t[2] Alterar CPF");
                Console.WriteLine("\t[3] Alterar E-mail");
                Console.WriteLine("\t[4] Alterar Endereço");
                Console.WriteLine("\t[5] Alterar Telefone");
                Console.WriteLine("\t[6] Alterar Senha");
                Console.WriteLine("\t[0] Voltar\n");
                Console.Write("Resposta: ");

                try
                {
                    respAlterar = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respAlterar = -1;
                }

                Console.Clear();
                switch (respAlterar)
                {
                    case 1:
                        AlterarNome();
                        break;

                    case 2:
                        AlterarCPF();
                        break;

                    case 3:
                        AlterarEmail();
                        break;

                    case 4:
                        AlterarEndereco();
                        break;

                    case 5:
                        AlterarTelefone();
                        break;

                    case 6:
                        AlterarSenha();
                        break;

                    case 0:
                        break;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.\n");
                        break;
                }

            } while (respAlterar != 0);
        }

        public void AlterarDadosFuncionario(Funcionario funcionario)
        {
            int respAlterar;

            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR PERFIL -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Alterar Nome");
                Console.WriteLine("\t[2] Alterar CPF");
                Console.WriteLine("\t[3] Alterar E-mail");
                Console.WriteLine("\t[4] Alterar Endereço");
                Console.WriteLine("\t[5] Alterar Telefone");
                Console.WriteLine("\t[6] Enviar Senha Temporária");
                Console.WriteLine("\t[0] Voltar\n");
                Console.Write("Resposta: ");

                try
                {
                    respAlterar = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respAlterar = -1;
                }

                Console.Clear();
                switch (respAlterar)
                {
                    case 1:
                        AlterarNome(funcionario);
                        break;

                    case 2:
                        AlterarCPF(funcionario);
                        break;

                    case 3:
                        AlterarEmail(funcionario);
                        break;

                    case 4:
                        AlterarEndereco(funcionario);
                        break;

                    case 5:
                        AlterarTelefone(funcionario);
                        break;

                    case 6:
                        Console.WriteLine($"Senha temporária enviada no e-mail {funcionario.GetEmail()} do funcionário {funcionario.GetId()}.\n");
                        break;

                    case 0:
                        break;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.\n");
                        break;
                }

            } while (respAlterar != 0);
        }

        // Alterar Nome
        public void AlterarNome()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR NOME -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Nome atual: {GetNome()}");
            SetNome(LerNome());
        }
        public void AlterarNome(Funcionario funcionario)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR NOME -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Nome atual: {funcionario.GetNome()}");
            funcionario.SetNome(LerNome());
        }

        // Alterar CPF
        public void AlterarCPF()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR CPF -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"CPF atual: {GetCPF()}");
            SetCPF(LerCPF(11));
        }
        public void AlterarCPF(Funcionario funcionario)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR CPF -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"CPF atual: {funcionario.GetCPF()}");
            funcionario.SetCPF(LerCPF(11));
        }

        // Alterar E-mail
        public void AlterarEmail()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR E-MAIL -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"E-mail atual: {GetEmail()}");
            SetEmail(LerEmail());
        }
        public void AlterarEmail(Funcionario funcionario)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR E-MAIL -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"E-mail atual: {funcionario.GetEmail()}");
            funcionario.SetEmail(LerEmail());
        }

        // Alterar Endereço
        public void AlterarEndereco()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR ENDEREÇO -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Endereço atual: {GetEndereco()}");
            SetNome(LerEndereco());
        }
        public void AlterarEndereco(Funcionario funcionario)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR ENDEREÇO -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Endereço atual: {funcionario.GetEndereco()}");
            funcionario.SetNome(LerEndereco());
        }

        // Alterar Telefone
        public void AlterarTelefone()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR TELEFONE -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Telefone atual: {GetTelefone()}");
            SetNome(LerTelefone());
        }
        public void AlterarTelefone(Funcionario funcionario)
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR TELEFONE -=-=-=-=-=-=-=-=-\n");
            Console.WriteLine($"Telefone atual: {funcionario.GetTelefone()}");
            funcionario.SetNome(LerTelefone());
        }
    }
}
