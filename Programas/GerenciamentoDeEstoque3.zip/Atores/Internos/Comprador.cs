﻿using GerenciamentoDeEstoque.Objetos.Estoque;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Atores.Internos
{
    public class Comprador : Funcionario
    {
        Dictionary<string, Cotacao> listaCotacao = new Dictionary<string, Cotacao>();
        public Comprador(string nome, string cpf, string email, string login, string senha, string endereco, string telefone)
            : base(nome, cpf, email, login, senha, endereco, telefone)
        {
            tipoFuncionario = 'C';
            id = tipoFuncionario + "-" + id;
        }

        // Menu
        public override void Menu()
        {
            do
            {
                Console.WriteLine("-=-=-=-=-=-=-=- MENU DO COMPRADOR -=-=-=-=-=-=-=-=-\n");
                Console.WriteLine("O que deseja fazer?\n");
                Console.WriteLine("\t[1] Criar Cotação");
                Console.WriteLine("\t[2] Exibir Cotações");
                Console.WriteLine("\t[3] Alterar Status da Cotação");
                Console.WriteLine("\t[4] Alterar Data Limite");
                Console.WriteLine("\t[5] Adicionar Item à Cotação");
                Console.WriteLine("\t[6] Remover Item da Cotação");
                Console.WriteLine("\t[7] Adicionar Fornecedor à Cotação");
                Console.WriteLine("\t[8] Remover Fornecedor da Cotação");
                Console.WriteLine("\t[9] Visualizar Perfil");
                Console.WriteLine("\t[10] Alterar Senha");
                Console.WriteLine("\t[0] Logoff\n");
                Console.Write("Resposta: ");

                int respostaC;
                try
                {
                    respostaC = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    respostaC = -1;
                }

                Console.Clear();
                switch (respostaC)
                {
                    case 1:
                        CriarCotacao();
                        break;

                    case 2:
                        Console.WriteLine("-=-=-=-=-=-=-=- LISTA DE COTAÇÕES -=-=-=-=-=-=-=-=-\n");
                        ExibirCotacoes();
                        Console.Write("Aperte 'Enter' para continuar...");
                        Console.ReadLine();
                        Console.Clear();
                        break;

                    case 3:
                        AlterarStatusCotacao();
                        break;

                    case 4:
                        AlterarDataVencimento();
                        break;

                    case 5:
                        //AdicionarItem();
                        break;

                    case 6:
                        //RemoverItem();
                        break;

                    case 7:
                        //AdicionarFornecedor();
                        break;

                    case 8:
                        //RemoverFornecedor();
                        break;

                    case 9:
                        VisualizarDados();
                        break;

                    case 10:
                        AlterarSenha();
                        break;

                    case 0:
                        Logoff();
                        break;

                    default:
                        Console.WriteLine("Opção inválida!\n");
                        break;
                }
            } while (estaLogado);
        }

        // Métodos do Comprador
        public void CriarCotacao()
        {
            Cotacao cotacao = new Cotacao(id);
            listaCotacao.Add(cotacao.GetIdCotacao(), cotacao);
            Console.Clear();
            Console.WriteLine("Cotação criada com sucesso!\n");
        }
        public void ExibirCotacoes()
        {
            foreach (KeyValuePair<string, Cotacao> cotacao in listaCotacao)
            {
                Console.WriteLine($"ID Cotação: {cotacao.Key} \nData de Criação: {cotacao.Value.GetDataCriacao().ToString("dd/MM/yyyy")} \nData de Vencimento: {cotacao.Value.GetDataVencimento().ToString("dd/MM/yyyy")} \nComprador: {nome} \nStatus: {cotacao.Value.GetStatus()}\n");
            }
        }
        public void AlterarStatusCotacao()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR STATUS -=-=-=-=-=-=-=-=-\n");
            ExibirCotacoes();

            while (true)
            {
                Console.Write("Digite o ID da cotação a ter o status alterado ou 'C' para cancelar a operação: ");
                string idCotacao = Console.ReadLine();

                if (idCotacao.ToUpper() == "C")
                {
                    Console.Clear();
                    Console.WriteLine("Operação cancelada pelo usuário.\n");
                    return;
                }

                if (listaCotacao.ContainsKey(idCotacao))
                {
                    Console.Clear();
                    Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR STATUS -=-=-=-=-=-=-=-=-\n");
                    Console.Write("O que deseja fazer: \n\n\t[1] Confirmar Cotação \n\t[2] Recusar Cotação \n\nResposta: ");
                    string resposta = Console.ReadLine();

                    if (resposta == "1")
                    {
                        listaCotacao[idCotacao].AlterarStatus(2);
                    }
                    else if (resposta == "2")
                    {
                        listaCotacao[idCotacao].AlterarStatus(3);
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Resposta inválida.\n");
                        return;
                    }

                    Console.Clear();
                    Console.WriteLine("Status alterado com sucesso!\n");
                    return;
                }
                else
                {
                    Console.WriteLine("ID não encontrado. Tente novamente.\n");
                }
            }
        }


        public void AlterarDataVencimento()
        {
            Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR DATA LIMITE -=-=-=-=-=-=-=-=-\n");
            ExibirCotacoes();

            string idCotacao;
            do
            {
                Console.Write("Digite o ID da cotação a ter a data de validade alterada ou digite 'C' para cancelar: ");
                idCotacao = Console.ReadLine();

                if (idCotacao.ToUpper() == "C")
                {
                    Console.Clear();
                    Console.WriteLine("Operação cancelada pelo usuário.");
                    return;
                }

                if (listaCotacao.ContainsKey(idCotacao))
                {
                    DateTime data;
                    Console.Clear();
                    Console.WriteLine("-=-=-=-=-=-=-=- ALTERAR DATA LIMITE -=-=-=-=-=-=-=-=-\n");
                    Console.WriteLine($"Data de Vencimento atual: {listaCotacao[idCotacao].GetDataVencimento().ToString("dd/MM/yyyy")}");
                    do
                    {
                        Console.Write("Digite a nova data limite: ");

                        try
                        {
                            data = DateTime.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Valor inválido. Tente novamente.\n");
                            continue;
                        }
                    
                        if (data < listaCotacao[idCotacao].GetDataCriacao())
                        {
                            Console.WriteLine("A data de vencimento não pode ser anterior à data de criação.\n");
                        }
                        else
                        {
                            Console.Clear();
                            listaCotacao[idCotacao].AlterarDataVencimento(data);
                            Console.WriteLine("Data de Vencimento alterada com sucesso!\n");
                            return;
                        }
                    } while (true);
                }
                else
                {
                    Console.WriteLine("\nID não encontrado. Tente novamente.\n");
                }
            } while (true);
        }
    }
}
