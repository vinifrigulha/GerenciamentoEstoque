﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoDeEstoque.Objetos.Estoque
{
    internal class Produto
    {
        private string idProduto;
        private string descricao;
        private decimal valor;
        private DateTime dataValidade;
        private int estoque;
        private string unidadeVenda;
        private string localizacaoEstoque;
        private int diasParado;
    }
}
